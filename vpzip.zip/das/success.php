<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="donor_reg" style="background-color:#fff;">
		<h1 class="text-center" style="background-color:#0616BC;color: #fff;padding: 5px;">Successful</h1>
		
			<p class="text-center">Your message has been sent!</p>
		
	</div>
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


	
</body>
</html>