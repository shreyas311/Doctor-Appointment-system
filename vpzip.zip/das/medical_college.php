<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="form-group mc">
		<h2 class="text-center" style="background-color:#272327;color: #fff;">Hospitals in our Network</h2>

                              <table cellpadding="10" cellspacing="10" class="table table-hover">   

                                  <tr>
                                      <th>No.</th><th>Name</th><th>Acronym</th><th>Established</th><th>Location</th><th>website</td>
                                  </tr>
                                  <tr>
                                      <td>01</td><td>Dr. Ithape Hospital</td><td>IH</td><td>1946</td><td>Sangamner</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>02</td><td>Dr.Tambe Hospital</td><td>TH</td><td>1972</td><td>Sangamner</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>03</td><td> Dr. Sonambekar Multispeciality Hospital Sangamner
                                      </td><td>SMHS</td><td>2006</td><td>Sangamner</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>04</td><td>Waghadkar general hospital</td><td>WGH</td><td>1962</td><td>Kopargaon</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>05</td><td>Kshatriya Hospital</td><td>KH</td><td>1957</td><td>Kopargaon</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>06</td><td>Rural Hospital Kopargaon</td><td>RHK</td><td>1958</td><td>Kopargaon</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>07</td><td>Rathi Hospital</td><td>RH</td><td>1999</td><td>Kopargaon</td><td><a href="#">website</a></td>
                                  </tr>
                                  <tr>
                                      <td>08</td><td>Dhanvantari Ayruvedic Hospital</td><td>DAH</td><td>1968</td><td>Kopargaon</td><td><a href="#">website</a></td>
                                  </tr>
                                  
                                  
                              </table>
	</div>
	

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
		<!-- footer section Ends--> 


	
	</div><!--  containerFluid Ends -->



	<script src="js/bootstrap.min.js"></script>
	
</body>
</html>