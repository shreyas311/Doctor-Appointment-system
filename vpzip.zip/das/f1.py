
import cv2
import mysql.connector

# Connect to the MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="yourusername",
    password="yourpassword",
    database="yourdatabase"
)

# Create a cursor object to execute SQL queries
cursor = db.cursor()

# Open the default camera
cap = cv2.VideoCapture(0)

# Read a frame from the camera
ret, frame = cap.read()

# Save the image to a file
cv2.imwrite("image.jpg", frame)

# Read the image file as binary data
with open("image.jpg", "rb") as f:
    img_data = f.read()

# Insert the image into the database
sql = "INSERT INTO images (data) VALUES (%s)"
values = (img_data,)
cursor.execute(sql, values)

# Commit the changes to the database
db.commit()

# Close the camera and database connection
cap.release()
cursor.close()
db.close()
