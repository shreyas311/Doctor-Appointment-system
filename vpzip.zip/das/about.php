<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">About Us</h3>
		<div class="col-md-12">
			<div class="col-md-6">
				<img src="img/aboutimag33.jpg" alt="" class="img-responsive">
			</div>

			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">We are Beside you</h3>
					<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt et dolores neque eaque. Labore, dicta similique ipsam odit saepe obcaecati suscipit ducimus, commodi dolores animi sed beatae, quia nulla facilis.lorem 
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi.</p>
				</article>
			</div>
		</div>


		<div class="col-md-12">
			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">24/7 hour service</h3>
					<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt et dolores neque eaque. Labore, dicta similique ipsam odit saepe obcaecati suscipit ducimus, commodi dolores animi sed beatae, quia nulla facilis.lorem 
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, doloribus quisquam eaque inventore consectetur sapiente itaque aliquid quae tempore. Eveniet iusto obcaecati magni qui laboriosam saepe unde, totam odio excepturi.</p>
				</article>
			</div>
			<div class="col-md-6">
				<img src="img/aboutimag11.jpg" alt="" class="img-responsive"><br>
			</div>
		</div>
          
    </div>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>